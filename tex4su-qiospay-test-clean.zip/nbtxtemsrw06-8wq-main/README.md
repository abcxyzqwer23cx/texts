# Website source — Cashify removed (safe test package)

This package removes Cashify payment endpoints and embedded credentials. Payment endpoints return HTTP 503 and do not accept payments. `api/qiospay-test-scaffold.js` is a non-networking test scaffold only; it does not create QRIS invoices or verify live payment.

Before deployment, configure panel and Telegram secrets as environment variables. Never commit `.env` or share API tokens. The live payment gateway must be configured and reviewed by an authorized merchant account holder against current official QiosPay documentation.
