// QiosPay TEST-INTEGRATION SCAFFOLD (no live transactions)
// Use this file for local planning/testing only. It does not contact QiosPay.
// A live merchant integration must be configured by an authorized account holder
// using the provider's current official docs and credentials stored server-side.

const TEST_MODE = true;

function assertTestMode() {
  if (!TEST_MODE) throw new Error('This scaffold is test-only.');
}

async function createInvoiceExample({ orderId, amount }) {
  assertTestMode();
  if (!orderId || !Number.isFinite(Number(amount)) || Number(amount) <= 0) {
    throw new Error('orderId and positive amount required');
  }
  return {
    mode: 'test',
    status: 'pending',
    order_id: String(orderId),
    amount: Number(amount),
    message: 'Demo response only. No QRIS invoice was created.'
  };
}

function verifyWebhookExample() {
  assertTestMode();
  return { verified: false, message: 'Webhook signature verification is not implemented in this test scaffold.' };
}

module.exports = { TEST_MODE, createInvoiceExample, verifyWebhookExample };
