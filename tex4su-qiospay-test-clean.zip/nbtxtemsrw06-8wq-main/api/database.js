

const fetch = require('node-fetch');
const QRCode = require('qrcode');
const crypto = require('crypto');

// ----------------------------- CONFIG -----------------------------
const config = {
  domain: process.env.DOMAIN || 'https://paneltex4su.serverprivtex.my.id/',
  apikey: process.env.PTLA || '',
  capikey: process.env.PTLC || '',
  eggid: process.env.EGGID || '15',
  nestid: process.env.NESTID || '5',
  location: process.env.LOC || '1',
  // Payment gateway intentionally disabled in this package; use the QiosPay test integration scaffold.
  DEFAULT_QRIS_EXPIRE_MINUTES: Number(process.env.QRIS_EXPIRE_MINUTES || 15),
  DEBUG: (process.env.DEBUG === '1' || process.env.DEBUG === 'true') || false,
  RATE_LIMIT_WINDOW_MS: Number(process.env.RATE_LIMIT_WINDOW_MS || 60_000), // 1 minute window
  RATE_LIMIT_MAX: Number(process.env.RATE_LIMIT_MAX || 10) 
};

const TELEGRAM_TOKEN = process.env.TELEGRAM_TOKEN || '';
const TELEGRAM_CHATID = process.env.TELEGRAM_CHATID || '';

// ----------------------------- PACKAGES (1GB -> 10GB + unlimited + reseller) -----------------------------
const PACKAGES = {
  "1gb":  { ram: 1024,  disk: 10240,   cpu: 100,  name: "1 GB",  price: 999,  desc: "Paket starter untuk belajar & testing" },
  "2gb":  { ram: 2048,  disk: 20480,   cpu: 200,  name: "2 GB",  price: 2000,  desc: "Paket 2gb" },
  "3gb":  { ram: 3072,  disk: 30720,   cpu: 300,  name: "3 GB",  price: 3000,  desc: "Paket 3gb" },
  "4gb":  { ram: 4096,  disk: 40960,   cpu: 400,  name: "4 GB",  price: 4000,  desc: "Paket 4gb" },
  "5gb":  { ram: 5120,  disk: 51200,   cpu: 500,  name: "5 GB",  price: 5000,  desc: "Paket 5gb" },
  "6gb":  { ram: 6144,  disk: 61440,   cpu: 600,  name: "6 GB",  price: 5600,  desc: "Paket 6gb" },
  "7gb":  { ram: 7168,  disk: 71680,   cpu: 700,  name: "7 GB",  price: 6700,  desc: "Paket 7gb" },
  "8gb":  { ram: 8192,  disk: 81920,   cpu: 800,  name: "8 GB",  price: 7800,  desc: "Paket 8gb" },
  "9gb":  { ram: 9216,  disk: 92160,   cpu: 900,  name: "9 GB",  price: 8900,  desc: "Paket 9gb" },
  "10gb": { ram: 10240, disk: 102400,  cpu: 1000, name: "10 GB", price: 9100, desc: "Paket 10gb" },
  "unlimited": { ram: 0, disk: 0, cpu: 0, name: "Unlimited", price: 10000, desc: "Paket Unlimited" },
  "reseller":  { ram: 0, disk: 0, cpu: 0, name: "Reseller",  price: 15000, desc: "Khusus reseller — bisa jualan panel sendiri" }
};

// ----------------------------- IN-MEMORY RATE LIMIT (simple) -----------------------------
const rateStore = new Map(); // key: ip, value: { count, windowStart }

function checkRateLimit(ip) {
  const now = Date.now();
  const rec = rateStore.get(ip);
  if (!rec) {
    rateStore.set(ip, { count: 1, windowStart: now });
    return { ok: true };
  }
  if (now - rec.windowStart > config.RATE_LIMIT_WINDOW_MS) {
    // reset window
    rateStore.set(ip, { count: 1, windowStart: now });
    return { ok: true };
  }
  if (rec.count >= config.RATE_LIMIT_MAX) {
    return { ok: false, retryAfterMs: rec.windowStart + config.RATE_LIMIT_WINDOW_MS - now };
  }
  rec.count++;
  return { ok: true };
}

// ----------------------------- HELPERS -----------------------------
function timeout(ms) { return new Promise(r => setTimeout(r, ms)); }
function logDebug(...args) { if (config.DEBUG) console.log('[DEBUG]', ...args); }
function maskSecret(s) { if (!s) return '<<empty>>'; if (s.length < 8) return '***'; return s.slice(0,6) + '...' + s.slice(-4); }

function fmtWIB(iso) {
  try {
    return new Date(iso).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
  } catch (e) {
    return iso;
  }
}

async function sendToTelegram(msg) {
  if (!TELEGRAM_TOKEN || !TELEGRAM_CHATID) return;
  try {
    await fetch(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type':'application/json' },
      body: JSON.stringify({
        chat_id: TELEGRAM_CHATID,
        text: msg,
        parse_mode: 'HTML'
      })
    });
  } catch (e) {
    console.error('sendToTelegram error:', e.message);
  }
}

async function fetchWithRetries(url, options = {}, { timeoutMs = 15000, retries = 2, retryDelayMs = 500 } = {}) {
  let lastErr = null;
  for (let attempt = 0; attempt <= retries; attempt++) {
    const controller = new AbortController();
    const opts = Object.assign({}, options, { signal: controller.signal });
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      logDebug(`fetch attempt ${attempt+1}/${retries+1} -> ${url}`);
      const res = await fetch(url, opts);
      clearTimeout(timer);
      return res;
    } catch (err) {
      clearTimeout(timer);
      lastErr = err;
      logDebug(`fetch error attempt ${attempt+1}:`, err && err.message);
      if (attempt < retries) await timeout(retryDelayMs * (attempt+1));
    }
  }
  throw lastErr;
}



async function safeParseResponse(res) {
  try {
    const json = await res.json();
    return { ok: true, body: json, status: res.status };
  } catch (err) {
    try {
      const txt = await res.text();
      return { ok: true, body: { __rawText: txt }, status: res.status };
    } catch (e) {
      return { ok: false, error: 'parse_failed' };
    }
  }
}

async function generateQrImageDataUrl(qrString) {
  if (!qrString) return null;
  try {
    const buf = await QRCode.toBuffer(qrString, { type: 'png', width: 420, margin: 1 });
    return 'data:image/png;base64,' + buf.toString('base64');
  } catch (e) {
    logDebug('QR gen failed:', e && e.message);
    return null;
  }
}



function fmtWIB(iso) { try { return new Date(iso).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }); } catch (e) { return iso; } }
function getField(obj, ...names) { if (!obj) return null; for (const n of names) if (obj[n] !== undefined && obj[n] !== null) return obj[n]; return null; }

// ----------------------------- CREATE PANEL (UPDATED) -----------------------------
async function CreatePanel(paketKey, username) {
  if (!paketKey) throw new Error('paketKey required');
  if (!username) throw new Error('username required');

  const key = String(paketKey).toLowerCase();
  const pkg = PACKAGES[key];
  if (!pkg) throw new Error('Paket tidak ditemukan: ' + paketKey);

  if (key === 'reseller') {
    return { reseller: true, message: 'Reseller detected. Manual handling required.' };
  }

  const memory = pkg.ram ? String(pkg.ram) : "0";
  const disk = pkg.disk ? String(pkg.disk) : "0";
  const cpu = pkg.cpu ? String(pkg.cpu) : "0";

  const password = crypto.randomBytes(6).toString('hex');
  const email = `${username}_${Date.now()}@wanzpanel.dev`;

  // ✅ STEP 0: cek domain bisa diakses
  try {
    const ping = await fetchWithRetries(config.domain.replace(/\/$/, '') + "/api/application/nodes", {
      headers: { 'Authorization': 'Bearer ' + config.apikey }
    }, { timeoutMs: 8000, retries: 0 });

    if (!ping.ok) {
      throw new Error('Domain panel tidak bisa diakses, hubungi admin untuk domain baru.');
    }
  } catch (err) {
    throw new Error('Domain panel tidak bisa diakses / timeout: ' + (err.message || err));
  }

  // ✅ STEP 1: cek apakah username sudah ada
  const checkUrl = `${config.domain.replace(/\/$/, '')}/api/application/users?filter[email]=${encodeURIComponent(email)}`;
  try {
    const checkResp = await fetchWithRetries(checkUrl, {
      headers: { 'Authorization': 'Bearer ' + config.apikey, 'Accept': 'application/json' }
    }, { timeoutMs: 10000, retries: 1 });

    const checkParsed = await safeParseResponse(checkResp);
    if (checkResp.ok && checkParsed.body && checkParsed.body.data && checkParsed.body.data.length > 0) {
      throw new Error('Username sudah digunakan, silakan pilih username lain.');
    }
  } catch (err) {
    if (/Username sudah digunakan/.test(err.message)) throw err;
    // lanjut saja kalau gagal cek, biar bisa tetap create
  }

  // ✅ STEP 2: create user
  const urlUser = `${config.domain.replace(/\/$/, '')}/api/application/users`;
  const userResp = await fetchWithRetries(urlUser, {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + config.apikey
    },
    body: JSON.stringify({
      email,
      username,
      first_name: username,
      last_name: username,
      password
    })
  }, { timeoutMs: 20000, retries: 2, retryDelayMs: 600 });

  const parsedUser = await safeParseResponse(userResp);
  if (!userResp.ok) {
    const detail = parsedUser.body || parsedUser.error || 'no details';
    throw new Error('Gagal membuat user: ' + JSON.stringify(detail));
  }

  const userData = parsedUser.body;
  const userObj = getField(userData, 'attributes') || getField(userData, 'data') || userData;
  const userId = getField(userObj, 'id') || getField(userObj, 'user', 'user_id') || null;
  if (!userId) throw new Error('User dibuat, tapi ID tidak ditemukan (konfigurasi panel failed).');

  // ✅ STEP 3: get egg startup
  let startup_cmd = 'npm start';
  try {
    const eggUrl = `${config.domain.replace(/\/$/, '')}/api/application/nests/${config.nestid}/eggs/${config.eggid}`;
    const eggResp = await fetchWithRetries(eggUrl, {
      headers: { 'Accept': 'application/json', 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + config.apikey }
    }, { timeoutMs: 15000, retries: 1 });

    const parsedEgg = await safeParseResponse(eggResp);
    const eggData = parsedEgg.body || {};
    startup_cmd = getField(eggData, 'attributes')?.startup || 'npm start';
  } catch (err) {
    throw new Error('Gagal mengambil konfigurasi Egg (panel gagal).');
  }

  // ✅ STEP 4: create server
  const serverUrl = `${config.domain.replace(/\/$/, '')}/api/application/servers`;
  const serverBody = {
    name: username,
    user: userId,
    egg: parseInt(config.eggid),
    docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
    startup: startup_cmd,
    environment: { INST: 'npm', USER_UPLOAD: '0', AUTO_UPDATE: '0', CMD_RUN: 'npm start' },
    limits: { memory, swap: 0, disk, io: 500, cpu },
    feature_limits: { databases: 0, backups: 0, allocations: 0 },
    deploy: { locations: [parseInt(config.location)], dedicated_ip: false, port_range: [] }
  };

  const serverResp = await fetchWithRetries(serverUrl, {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + config.apikey
    },
    body: JSON.stringify(serverBody)
  }, { timeoutMs: 25000, retries: 2, retryDelayMs: 800 });

  const parsedServer = await safeParseResponse(serverResp);
  if (!serverResp.ok) {
    const detail = parsedServer.body || parsedServer.error || 'no details';
    throw new Error('Konfigurasi panel failed saat buat server: ' + JSON.stringify(detail));
  }

  const serverData = parsedServer.body;
  const serverAttrs = getField(serverData, 'attributes') || getField(serverData, 'data')?.attributes || serverData;
  const serverId = getField(serverAttrs, 'id') || getField(serverAttrs, 'identifier') || null;

  return {
    userId,
    serverId,
    username: getField(userObj, 'username') || username,
    password,
    paket: pkg.name || paketKey,
    domain: config.domain
  };
}

// ----------------------------- SERVERLESS HANDLER -----------------------------
module.exports = async (req, res) => {
  try {
    // CORS preflight
    if (req.method === 'OPTIONS') {
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
      return res.status(200).end();
    }

    // Basic CORS
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    // simple rate-limit by IP
    const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket?.remoteAddress || 'unknown';
    const rl = checkRateLimit(ip);
    if (!rl.ok) {
      const retryAfterSec = Math.ceil((rl.retryAfterMs || 0) / 1000) || 30;
      res.setHeader('Retry-After', String(retryAfterSec));
      return res.status(429).json({ ok: false, error: 'Too many requests', retryAfterSec });
    }

    const action = req.query?.action ? String(req.query.action) : null;

if (action === "total-orders") {
  const db = await loadDB();
  const total = db.filter(x => x.status === "paid").length;
  return res.json({ total });
              }
              
    // ---------- HANDLE: action=status ----------
if (action === 'status') {
  try {
    const domain = config.domain || config.DOMAIN || '';
    const plta   = config.apikey   || config.PTLA   || '';
    const pltc   = config.capikey   || config.PTLC   || '';

    // Jika salah satu belum diisi → OFFLINE
    if (!domain || !plta || !pltc) {
      global.status = false;
      return res.status(200).json({
        status: 'offline'
      });
    }

    // Kalau semua ada → ONLINE
    global.status = true;
    return res.status(200).json({
      status: 'online'
    });

  } catch (e) {
    global.status = false;
    return res.status(200).json({
      status: 'offline'
    });
  }
}

    // ---------- PAYMENT GATEWAY (DISABLED SAFE PACKAGE) ----------
    // Live QRIS payment processing is not configured in this build.
    // QiosPay test integration notes are in api/qiospay-test-scaffold.js.
    if ((action === 'create-qris' || action === 'check-status') && req.method === 'POST') {
      return res.status(503).json({
        ok: false,
        provider: 'QiosPay',
        mode: 'test-scaffold-only',
        error: 'Payment gateway is not configured. Do not accept payments in this package.'
      });
    }

    // unknown action
    return res.status(404).json({ ok: false, error: 'Invalid action (payment endpoints are disabled in this safe package)' });

    // simple visit log
const visitorIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket?.remoteAddress || 'unknown';
const ua = req.headers['user-agent'] || 'unknown';
const timeWIB = fmtWIB(new Date().toISOString());

const msg = `
👋 <b>Halo kak!</b> ada pengunjung baru nih

🌐 <b>Website</b>: Order Panel
📡 <b>IP Address</b>: <code>${visitorIp}</code>
🖥️ <b>Device/UA</b>: <code>${ua}</code>
📅 <b>Tanggal & Jam (WIB)</b>: ${timeWIB}

━━━━━━━━━━━━━━━━━━━━
<i>Notifikasi otomatis dari sistem</i> 💻
`;

sendToTelegram(msg);
            
              
  } catch (err) {
    console.error('database.js ERROR:', err && (err.stack || err.message || err));
    return res.status(500).json({ ok: false, error: err && err.message ? err.message : 'internal server error' });
  }
};
